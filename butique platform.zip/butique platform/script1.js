// Mobile Menu Toggle
const menuBtn = document.querySelector(".menu-btn");
const navLinks = document.querySelector(".nav-links");

if (menuBtn) {
  menuBtn.addEventListener("click", () => {
    navLinks.classList.toggle("active");
  });
}

// -------------------- REGISTER --------------------
const registerForm = document.getElementById("registerForm");
const registerMsg = document.getElementById("registerMsg");

if (registerForm) {
  registerForm.addEventListener("submit", function (e) {
    e.preventDefault();

    const userData = {
      name: document.getElementById("regName").value,
      email: document.getElementById("regEmail").value,
      password: document.getElementById("regPassword").value,
    };

    localStorage.setItem("embeyvally_user", JSON.stringify(userData));

    registerMsg.style.display = "block";
    registerForm.reset();

    setTimeout(() => {
      registerMsg.style.display = "none";
    }, 3000);
  });
}

// -------------------- LOGIN --------------------
const loginForm = document.getElementById("loginForm");
const loginMsg = document.getElementById("loginMsg");
const loginError = document.getElementById("loginError");

if (loginForm) {
  loginForm.addEventListener("submit", function (e) {
    e.preventDefault();

    const savedUser = JSON.parse(localStorage.getItem("embeyvally_user"));

    const email = document.getElementById("loginEmail").value;
    const password = document.getElementById("loginPassword").value;

    if (savedUser && email === savedUser.email && password === savedUser.password) {
      localStorage.setItem("embeyvally_loggedin", "true");
      loginMsg.style.display = "block";
      loginError.style.display = "none";

      setTimeout(() => {
        loginMsg.style.display = "none";
      }, 3000);
    } else {
      loginError.style.display = "block";
      loginMsg.style.display = "none";
    }
  });
}

// -------------------- LOGOUT --------------------
function logoutUser() {
  localStorage.removeItem("embeyvally_loggedin");
  alert("You are logged out successfully!");
}

// -------------------- TRACK ORDER --------------------
const trackForm = document.getElementById("trackForm");
const trackResult = document.getElementById("trackResult");

if (trackForm) {
  trackForm.addEventListener("submit", function (e) {
    e.preventDefault();

    const orderId = document.getElementById("orderId").value.toUpperCase();

    // Sample order statuses (demo)
    const orders = {
      EV1001: { status: "Stitching Started ✂", delivery: "3 Days" },
      EV1002: { status: "In Progress 🧵", delivery: "5 Days" },
      EV1003: { status: "Ready for Pickup 🎉", delivery: "1 Day" },
      EV1004: { status: "Delivered ✅", delivery: "Completed" },
    };

    if (orders[orderId]) {
      document.getElementById("showOrderId").innerText = orderId;
      document.getElementById("showStatus").innerText = orders[orderId].status;
      document.getElementById("showDelivery").innerText = orders[orderId].delivery;

      trackResult.style.display = "block";
    } else {
      alert("❌ Order ID not found! Please check and try again.");
      trackResult.style.display = "none";
    }
  });
}
